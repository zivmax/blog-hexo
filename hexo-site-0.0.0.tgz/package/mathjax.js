const mjAPI = require("mathjax-node");

function mathjax(data, options) {
    return new Promise((resolve, reject) => {
        mjAPI.start();
        mjAPI.typeset({
            math: data.text,
            format: "TeX",
            svg: true,
            speakText: false
        }, (result, data) => {
            if (!result.errors) {
                data.text = result.svg;
                resolve(data);
            } else {
                reject(result.errors);
            }
        });
    });
}
